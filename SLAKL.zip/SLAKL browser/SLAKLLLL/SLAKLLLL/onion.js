async function fetchFromOnion(onionUrl) {
    try {
        const response = await fetch('/api/fetch-onion', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ url: onionUrl })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.text(); // or response.json() if you expect JSON
        console.log(data);
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}


