const express = require('express');
const TorRequest = require('tor-request');

const app = express();
const port = 3000;

// Set up Tor proxy
TorRequest.setTorAddress('localhost', 9050);

// Middleware to parse JSON bodies
app.use(express.json());

// Endpoint to fetch data from a .onion URL
app.post('/api/fetch-onion', (req, res) => {
    const { url } = req.body;

    if (!url || !url.startsWith('http://') || !url.endsWith('.onion')) {
        return res.status(400).json({ error: 'Invalid .onion URL' });
    }

    TorRequest.request(url, (err, response, body) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.send(body);
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
