﻿namespace SLAKLLLL
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Soundcloud = new System.Windows.Forms.Button();
            this.Print = new System.Windows.Forms.Button();
            this.Search = new System.Windows.Forms.Button();
            this.SearchBox = new System.Windows.Forms.TextBox();
            this.Restart = new System.Windows.Forms.Button();
            this.Undo = new System.Windows.Forms.Button();
            this.Google = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.Home = new System.Windows.Forms.Button();
            this.Heart = new System.Windows.Forms.Button();
            this.Bing = new System.Windows.Forms.Button();
            this.DuckDuckGo = new System.Windows.Forms.Button();
            this.Brave = new System.Windows.Forms.Button();
            this.Yahoo = new System.Windows.Forms.Button();
            this.Gmail = new System.Windows.Forms.Button();
            this.Youtube = new System.Windows.Forms.Button();
            this.Bitcoin = new System.Windows.Forms.Button();
            this.VPN = new System.Windows.Forms.Button();
            this.Stocks = new System.Windows.Forms.Button();
            this.Spotify = new System.Windows.Forms.Button();
            this.Redo = new System.Windows.Forms.Button();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Soundcloud
            // 
            this.Soundcloud.Location = new System.Drawing.Point(570, 40);
            this.Soundcloud.Name = "Soundcloud";
            this.Soundcloud.Size = new System.Drawing.Size(97, 23);
            this.Soundcloud.TabIndex = 53;
            this.Soundcloud.Text = "♪ Soundcloud";
            this.Soundcloud.UseVisualStyleBackColor = true;
            this.Soundcloud.Click += new System.EventHandler(this.Soundcloud_Click);
            // 
            // Print
            // 
            this.Print.Location = new System.Drawing.Point(45, 40);
            this.Print.Name = "Print";
            this.Print.Size = new System.Drawing.Size(28, 23);
            this.Print.TabIndex = 52;
            this.Print.Text = "🖨";
            this.Print.UseVisualStyleBackColor = true;
            this.Print.Click += new System.EventHandler(this.Print_Click);
            // 
            // Search
            // 
            this.Search.Location = new System.Drawing.Point(1102, 11);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(28, 23);
            this.Search.TabIndex = 51;
            this.Search.Text = "⌕";
            this.Search.UseVisualStyleBackColor = true;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // SearchBox
            // 
            this.SearchBox.Location = new System.Drawing.Point(114, 10);
            this.SearchBox.Name = "SearchBox";
            this.SearchBox.Size = new System.Drawing.Size(982, 22);
            this.SearchBox.TabIndex = 50;
            // 
            // Restart
            // 
            this.Restart.Location = new System.Drawing.Point(45, 10);
            this.Restart.Name = "Restart";
            this.Restart.Size = new System.Drawing.Size(28, 23);
            this.Restart.TabIndex = 49;
            this.Restart.Text = "↻";
            this.Restart.UseVisualStyleBackColor = true;
            this.Restart.Click += new System.EventHandler(this.Restart_Click);
            // 
            // Undo
            // 
            this.Undo.Location = new System.Drawing.Point(79, 10);
            this.Undo.Name = "Undo";
            this.Undo.Size = new System.Drawing.Size(28, 23);
            this.Undo.TabIndex = 48;
            this.Undo.Text = "↩";
            this.Undo.UseVisualStyleBackColor = true;
            this.Undo.Click += new System.EventHandler(this.Undo_Click);
            // 
            // Google
            // 
            this.Google.ForeColor = System.Drawing.Color.Red;
            this.Google.Location = new System.Drawing.Point(114, 40);
            this.Google.Name = "Google";
            this.Google.Size = new System.Drawing.Size(28, 23);
            this.Google.TabIndex = 47;
            this.Google.Text = "G";
            this.Google.UseVisualStyleBackColor = true;
            this.Google.Click += new System.EventHandler(this.Google_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(1170, 10);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(28, 23);
            this.Exit.TabIndex = 46;
            this.Exit.Text = "❌";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Home
            // 
            this.Home.Location = new System.Drawing.Point(1136, 11);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(28, 23);
            this.Home.TabIndex = 44;
            this.Home.Text = "🏠︎";
            this.Home.UseVisualStyleBackColor = true;
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // Heart
            // 
            this.Heart.Location = new System.Drawing.Point(11, 40);
            this.Heart.Name = "Heart";
            this.Heart.Size = new System.Drawing.Size(28, 23);
            this.Heart.TabIndex = 43;
            this.Heart.Text = "★";
            this.Heart.UseVisualStyleBackColor = true;
            this.Heart.Click += new System.EventHandler(this.Heart_Click);
            // 
            // Bing
            // 
            this.Bing.ForeColor = System.Drawing.Color.MidnightBlue;
            this.Bing.Location = new System.Drawing.Point(148, 40);
            this.Bing.Name = "Bing";
            this.Bing.Size = new System.Drawing.Size(28, 23);
            this.Bing.TabIndex = 42;
            this.Bing.Text = "B";
            this.Bing.UseVisualStyleBackColor = true;
            this.Bing.Click += new System.EventHandler(this.Bing_Click);
            // 
            // DuckDuckGo
            // 
            this.DuckDuckGo.ForeColor = System.Drawing.Color.Lime;
            this.DuckDuckGo.Location = new System.Drawing.Point(250, 40);
            this.DuckDuckGo.Name = "DuckDuckGo";
            this.DuckDuckGo.Size = new System.Drawing.Size(28, 23);
            this.DuckDuckGo.TabIndex = 41;
            this.DuckDuckGo.Text = "D";
            this.DuckDuckGo.UseVisualStyleBackColor = true;
            this.DuckDuckGo.Click += new System.EventHandler(this.DuckDuckGo_Click);
            // 
            // Brave
            // 
            this.Brave.ForeColor = System.Drawing.Color.Orange;
            this.Brave.Location = new System.Drawing.Point(182, 40);
            this.Brave.Name = "Brave";
            this.Brave.Size = new System.Drawing.Size(28, 23);
            this.Brave.TabIndex = 40;
            this.Brave.Text = "B";
            this.Brave.UseVisualStyleBackColor = true;
            this.Brave.Click += new System.EventHandler(this.Brave_Click);
            // 
            // Yahoo
            // 
            this.Yahoo.ForeColor = System.Drawing.Color.DarkMagenta;
            this.Yahoo.Location = new System.Drawing.Point(216, 40);
            this.Yahoo.Name = "Yahoo";
            this.Yahoo.Size = new System.Drawing.Size(28, 23);
            this.Yahoo.TabIndex = 39;
            this.Yahoo.Text = "Y";
            this.Yahoo.UseVisualStyleBackColor = true;
            this.Yahoo.Click += new System.EventHandler(this.button8_Click);
            // 
            // Gmail
            // 
            this.Gmail.Location = new System.Drawing.Point(536, 40);
            this.Gmail.Name = "Gmail";
            this.Gmail.Size = new System.Drawing.Size(28, 23);
            this.Gmail.TabIndex = 38;
            this.Gmail.Text = "✉︎";
            this.Gmail.UseVisualStyleBackColor = true;
            this.Gmail.Click += new System.EventHandler(this.Gmail_Click);
            // 
            // Youtube
            // 
            this.Youtube.Location = new System.Drawing.Point(502, 40);
            this.Youtube.Name = "Youtube";
            this.Youtube.Size = new System.Drawing.Size(28, 23);
            this.Youtube.TabIndex = 37;
            this.Youtube.Text = "▷";
            this.Youtube.UseVisualStyleBackColor = true;
            this.Youtube.Click += new System.EventHandler(this.button6_Click);
            // 
            // Bitcoin
            // 
            this.Bitcoin.Location = new System.Drawing.Point(1170, 40);
            this.Bitcoin.Name = "Bitcoin";
            this.Bitcoin.Size = new System.Drawing.Size(28, 23);
            this.Bitcoin.TabIndex = 36;
            this.Bitcoin.Text = "₿";
            this.Bitcoin.UseVisualStyleBackColor = true;
            // 
            // VPN
            // 
            this.VPN.Location = new System.Drawing.Point(1102, 40);
            this.VPN.Name = "VPN";
            this.VPN.Size = new System.Drawing.Size(28, 23);
            this.VPN.TabIndex = 35;
            this.VPN.Text = "🛡️";
            this.VPN.UseVisualStyleBackColor = true;
            // 
            // Stocks
            // 
            this.Stocks.Location = new System.Drawing.Point(1136, 40);
            this.Stocks.Name = "Stocks";
            this.Stocks.Size = new System.Drawing.Size(28, 23);
            this.Stocks.TabIndex = 34;
            this.Stocks.Text = "📈";
            this.Stocks.UseVisualStyleBackColor = true;
            this.Stocks.Click += new System.EventHandler(this.Stocks_Click);
            // 
            // Spotify
            // 
            this.Spotify.Location = new System.Drawing.Point(673, 40);
            this.Spotify.Name = "Spotify";
            this.Spotify.Size = new System.Drawing.Size(71, 23);
            this.Spotify.TabIndex = 33;
            this.Spotify.Text = "♪ Spotify";
            this.Spotify.UseVisualStyleBackColor = true;
            this.Spotify.Click += new System.EventHandler(this.Spotify_Click);
            // 
            // Redo
            // 
            this.Redo.Location = new System.Drawing.Point(11, 10);
            this.Redo.Name = "Redo";
            this.Redo.Size = new System.Drawing.Size(28, 23);
            this.Redo.TabIndex = 32;
            this.Redo.Text = "↪";
            this.Redo.UseVisualStyleBackColor = true;
            this.Redo.Click += new System.EventHandler(this.Redo_Click);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(-1, 69);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(1211, 707);
            this.webBrowser1.TabIndex = 54;
            this.webBrowser1.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowser1_DocumentCompleted_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SLAKLLLL.Properties.Resources.ColorScehme;
            this.pictureBox2.Location = new System.Drawing.Point(856, -2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1201, 76);
            this.pictureBox2.TabIndex = 31;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SLAKLLLL.Properties.Resources.ColorScehme;
            this.pictureBox1.Location = new System.Drawing.Point(-1, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1211, 76);
            this.pictureBox1.TabIndex = 30;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1211, 769);
            this.Controls.Add(this.webBrowser1);
            this.Controls.Add(this.Soundcloud);
            this.Controls.Add(this.Print);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.SearchBox);
            this.Controls.Add(this.Restart);
            this.Controls.Add(this.Undo);
            this.Controls.Add(this.Google);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Home);
            this.Controls.Add(this.Heart);
            this.Controls.Add(this.Bing);
            this.Controls.Add(this.DuckDuckGo);
            this.Controls.Add(this.Brave);
            this.Controls.Add(this.Yahoo);
            this.Controls.Add(this.Gmail);
            this.Controls.Add(this.Youtube);
            this.Controls.Add(this.Bitcoin);
            this.Controls.Add(this.VPN);
            this.Controls.Add(this.Stocks);
            this.Controls.Add(this.Spotify);
            this.Controls.Add(this.Redo);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Soundcloud;
        private System.Windows.Forms.Button Print;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.TextBox SearchBox;
        private System.Windows.Forms.Button Restart;
        private System.Windows.Forms.Button Undo;
        private System.Windows.Forms.Button Google;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.Button Heart;
        private System.Windows.Forms.Button Bing;
        private System.Windows.Forms.Button DuckDuckGo;
        private System.Windows.Forms.Button Brave;
        private System.Windows.Forms.Button Yahoo;
        private System.Windows.Forms.Button Gmail;
        private System.Windows.Forms.Button Youtube;
        private System.Windows.Forms.Button Bitcoin;
        private System.Windows.Forms.Button VPN;
        private System.Windows.Forms.Button Stocks;
        private System.Windows.Forms.Button Spotify;
        private System.Windows.Forms.Button Redo;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.WebBrowser webBrowser1;
    }
}

