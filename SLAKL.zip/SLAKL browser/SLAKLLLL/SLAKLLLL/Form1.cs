﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SLAKLLLL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void webBrowser2_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {


        }

        private void button19_Click(object sender, EventArgs e)
        {

        }

        private void Search_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate(SearchBox.Text);
        }

        private void Undo_Click(object sender, EventArgs e)
        {
            webBrowser1.GoBack();
        }

        private void Restart_Click(object sender, EventArgs e)
        {
            webBrowser1.Refresh();
        }

        private void Redo_Click(object sender, EventArgs e)
        {
            webBrowser1.GoForward();
        }

        private void Home_Click(object sender, EventArgs e)
        {
            webBrowser1.GoHome();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Stocks_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://www.investing.com/charts/stocks-charts");
        }

        private void Spotify_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://open.spotify.com/");
        }

        private void Soundcloud_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://soundcloud.com/");
        }

        private void Gmail_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://mail.google.com/mail/u/0");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://www.youtube.com/");
        }

        private void DuckDuckGo_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://duckduckgo.com/");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://www.yahoo.com/");
        }

        private void Brave_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://search.brave.com/");
        }

        private void Bing_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://www.bing.com/");
        }

        private void Google_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://www.google.com/");
        }

        private void Print_Click(object sender, EventArgs e)
        {
            webBrowser1.Print();
        }

        private void webBrowser1_DocumentCompleted_1(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            string combinedJs = System.IO.File.ReadAllText("Adblocker.js") + "\n" +
                                System.IO.File.ReadAllText("onion.js") + "\n" +
                                System.IO.File.ReadAllText("access-onion.js") + "\n" +
                                System.IO.File.ReadAllText("server.js");

            webBrowser1.Document.InvokeScript("execScript", new object[] { combinedJs, "JavaScript" });

        }

        private void Heart_Click(object sender, EventArgs e)
        {

        }

        private void Settings_Click(object sender, EventArgs e)
        {

        }
    }
}
